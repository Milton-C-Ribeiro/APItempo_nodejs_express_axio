const express = require('express');
const axios = require('axios');
const app = express();
const port = 3050; // Porta da API Externa

// Habilitando JSON para requisições
app.use(express.json());

// Rota para obter dados de uma API de previsão do tempo
app.get('/api/externa', async (req, res) => {
  try {
    // API de previsão do tempo OpenWeatherMap
    const api_key = 'f0b00181c62b6bee5b3f5453f712aab2'; // Substitua pela sua chave API
    /*const api_key = 'your_api_key'; // Substitua pela sua chave API*/
    const response = await axios.get(`https://api.openweathermap.org/data/2.5/weather?q=São Paulo&appid=${api_key}`);
    const dadosClima = response.data;
    res.json(dadosClima);
  } catch (error) {
    console.error('Erro ao obter dados do clima:', error);
    res.status(500).json({ error: 'Erro ao obter dados do clima' });
  }
});

app.listen(port, () => {
  console.log(`API Externa rodando em http://localhost:${port}`);
});