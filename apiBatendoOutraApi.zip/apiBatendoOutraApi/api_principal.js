const express = require('express');
const axios = require('axios');
const app = express();
const port = 3040;

// Habilitando JSON para requisições
app.use(express.json());

// Rota para obter dados da API Externa
app.get('/api/dados', async (req, res) => {
  try {
    const response = await axios.get('http://localhost:3050/api/externa'); // Acessando a API Externa
    const dadosClima = response.data;
    res.json({ mensagem: 'Dados do Clima:', dados: dadosClima });
  } catch (error) {
    console.error('Erro ao obter dados do clima:', error);
    res.status(500).json({ error: 'Erro ao obter dados do clima' });
  }
});

app.listen(port, () => {
  console.log(`API Principal rodando em http://localhost:${port}`);
});

//instalar pm2: npm install pm2 -g
//roda: pm2 start ecosystem.config.js


//rodar comando: pm2 stop ecosystem.config.js -f
//rodar comando: pm2 restart ecosystem.config.js -f
